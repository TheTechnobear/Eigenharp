version = "2.0.76-stable"
cversion = "0.0.1"
plugin = "osc_pad"
